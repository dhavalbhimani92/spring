package com.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class AnagramDemo {
	public static char[] charArray;
	public AnagramDemo(String word){
		charArray=word.toCharArray();
		doAnagram(charArray.length);
	}
	public void changeOrder(int newsize){
		int j;
		int pointAt=charArray.length-newsize;
		char temp= charArray[pointAt];
		for(j=pointAt+1;j<charArray.length;j++){
			charArray[j-1]=charArray[j];
		}
		charArray[j-1]=temp;
	}
	public void doAnagram(int newsize){
		if(newsize==1){
			return;
		}
		for(int i=0; i<newsize;i++){
			doAnagram(newsize - 1);
			if(newsize==2){
				display();
			}
			changeOrder(newsize);
		}
	}
	public void display(){
		for(int i=0;i<charArray.length;i++){
			System.out.print(charArray[i]);
		}
		System.out.println();
	}
	public static void main(String[] args) throws Exception {
		System.out.println("Enter word for Anagram");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String s=br.readLine();
		AnagramDemo ad=new AnagramDemo(s);
		
		ad=null;
	}

}

package com.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.DepartmentDao;
import com.demo.dao.impl.DepartmentDaoImpl;
import com.demo.pojo.DepartmentBean;
import com.demo.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentDao departmentDao;// = new DepartmentDaoImpl();
	
	@Override
	public void saveOrUpdate(DepartmentBean departmentBean) {
		departmentDao.saveOrUpdate(departmentBean);
	}

	@Override
	public List<DepartmentBean> findAll(String departmentName) {
		return departmentDao.findAll(departmentName);
	}

	@Override
	public DepartmentBean find(Long departmentId) {
		return departmentDao.find(departmentId);
	}

	@Override
	public void delete(Long departmentId) {
		departmentDao.delete(departmentId);
	}

}

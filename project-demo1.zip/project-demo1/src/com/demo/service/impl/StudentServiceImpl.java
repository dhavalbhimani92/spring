package com.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.StudentDao;
import com.demo.pojo.DepartmentBean;
import com.demo.pojo.StudentBean;
import com.demo.service.StudentService;

@Service("studentService")
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentDao studentDao;

	@Override
	public void saveOrUpdate(StudentBean studentBean) {
		studentDao.saveOrUpdate(studentBean);
	}

	@Override
	public List<StudentBean> findAll(String studentName) {

		return studentDao.findAll(studentName);
	}

	@Override
	public StudentBean find(Long studentId) {
		return studentDao.find(studentId);
	}

	@Override
	public void delete(Long studentId) {
		studentDao.delete(studentId);
	}

}

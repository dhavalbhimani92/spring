package com.demo.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "STUDENT")
public class StudentBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2920827687583360520L;

	@Id
	@Column(name = "STUDENT_ID")
	@GeneratedValue
	private long studentId;

	@NotEmpty(message = "Required....")
	@Size(min = 1, max = 255)
	@Column(name = "STUDENT_NAME")
	private String studentName;

	@Column(name = "AGE")
	private Integer age;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE")
	private Date date;

	@ManyToOne
	@JoinColumn(name = "DEPARTMENT_ID")
	private DepartmentBean departmentBean;

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	/*
	 * public DepartmentBean getDepartment() { return department; }
	 * 
	 * public void setDepartment(DepartmentBean department) { this.department =
	 * department; }
	 */
	/**
	 * @return the departmentBean
	 */
	public DepartmentBean getDepartmentBean() {
		return departmentBean;
	}

	/**
	 * @param departmentBean
	 *            the departmentBean to set
	 */
	public void setDepartmentBean(DepartmentBean departmentBean) {
		this.departmentBean = departmentBean;
	}

}

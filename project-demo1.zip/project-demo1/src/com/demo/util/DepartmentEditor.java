package com.demo.util;

import java.beans.PropertyEditorSupport;
import java.util.Map;

import com.demo.pojo.DepartmentBean;

public class DepartmentEditor extends PropertyEditorSupport {

	private static Map<Long, DepartmentBean> departmentMap = null;

	public DepartmentEditor() {

	}

	public DepartmentEditor(Map<Long, DepartmentBean> departmentMap) {
		DepartmentEditor.departmentMap = departmentMap;
	}

	@Override
	public void setAsText(String id) {
		DepartmentBean departmentBean = departmentMap.get(Long.valueOf(id));
		this.setValue(departmentBean);
	}
}

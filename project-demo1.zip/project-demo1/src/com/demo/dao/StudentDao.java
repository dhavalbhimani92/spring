package com.demo.dao;

import java.util.List;

import com.demo.pojo.StudentBean;

public interface StudentDao {
	
	void saveOrUpdate(StudentBean studentBean);
	List<StudentBean> findAll(String studentName);
	StudentBean find(Long studentId);
	void delete(Long studentId);

}

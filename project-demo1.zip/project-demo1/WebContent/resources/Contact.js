$(document).ready(function(){
    $("#Main form").css({
    	"width" : $(window).width() + "px",
    	"height" : $(window).height() + "px",
    })
    
    	ValidateForm();
    	
    
});


// Function definition : <Enter a brief note of what this function does>
function ValidateForm(){
		// main code goes here
        $("#Submit_Btn").on("click", function(){
    		$(".Contact_Validation").remove();
           console.log("fname")
            // Validation for empty First Name field
            if ($("#FName_Txb").val().trim() == "") {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>First Name Invalid:</b> First Name cannot be empty. Please enter a valid First Name.</div>")
                $("#FName_Txb").focus()
                return
            }

            // Validation for empty Last Name field
            if ($("#LName_Txb").val().trim() == "") {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>Last Name Invalid:</b> Last Name cannot be empty. Please enter a valid Last Name.</div>")
                $("#LName_Txb").focus()
                return
            }

            // validation for First Name length 
            var xMaxLength = $("#FName_Txb").attr("maxlength")
            if ($("#FName_Txb").val().length > xMaxLength) {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>First Name Invalid:</b> First Name maximum length (" + xMaxLength + ")</div>")
                $("#FName_Txb").focus()
                return
            }

            // validation for Last Name length 
            var xMaxLength = $("#LName_Txb").attr("maxlength")
            if ($("#LName_Txb").val().length > xMaxLength) {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>Last Name Invalid:</b> Last Name maximum length (" + xMaxLength + ")</div>")
                $("#LName_Txb").focus()
                return
            }

            // Validation for empty Email field
            if ($("#Email_Txb").val().trim() == "") {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>Email Address Invalid:</b> Email Address cannot be empty. Please enter a valid email address.</div>")
                $("#Email_Txb").focus()
                return
            }

            // Validation for Email-id
            var xInputVal = $("#Email_Txb").val().trim()
            var ssnPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
            if (!ssnPattern.test(xInputVal)) {
                $("#Error_Div").append("<div class='Contact_Validation' style='color: red;'><b>Email Address Invalid:</b> Please enter a valid email address (e.g. username@gmail.com)</div>")
                $("#Email_Txb").focus()
                return
            }

        });
}
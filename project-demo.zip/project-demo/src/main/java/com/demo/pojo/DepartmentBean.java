package com.demo.pojo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;




@Entity
@Table(name = "DAPARTMENT")
public class DepartmentBean implements Serializable {

	private static final long serialVersionUID = -3251750071829549755L;

	
	@Id
	@GeneratedValue
	@Column(name = "DEPARTMENT_ID")
	private long departmentId;
	
	@NotNull(message="Required...")
	@Column(name = "DEPARTMENT_NAME",nullable=false)
	private String departmentName;

	@Size(min = 1, max = 25,message="Required..")
	@OneToMany(mappedBy = "departmentBean", cascade = CascadeType.ALL)
	private List<StudentBean> studentBean;

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public List<StudentBean> getStudentBean() {
		return studentBean;
	}

	public void setStudentBean(List<StudentBean> studentBean) {
		this.studentBean = studentBean;
	}
}

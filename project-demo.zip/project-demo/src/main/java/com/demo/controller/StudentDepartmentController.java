package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentDepartmentController {
	@RequestMapping("/")
	public String urlHandler(){
		return "home";
	}
	
	@RequestMapping("/home")
	public String homeNavigation(){
		return "home";
	}
	
	@RequestMapping("/studenthome")
	public String studentHome(){
		return "studentHome";
	}
	
	@RequestMapping("/departmenthome")
	public String departmentHome(){
		return "departmentHome";
	}


}

package com.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.pojo.DepartmentBean;
import com.demo.service.DepartmentService;

@Controller
@RequestMapping("/department/")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	

	@RequestMapping("/AddDepartment")
	public String departmentForm(@ModelAttribute("newDepartmentBean") DepartmentBean departmentBean,Model model){
		return "AddDepartment";
	}
	
	@RequestMapping("/viewDepartment")
	public String viewDepartment( Model model, 
			HttpServletRequest request, HttpServletResponse response){
		List<DepartmentBean> departments = departmentService.findAll(null);
		model.addAttribute("departments",departments);
		return "viewDepartment";
	}
	
	@RequestMapping("/searchDepartment")
	public String searchDepartment(@ModelAttribute("newDepartmentBean")DepartmentBean departmentBean){
		return "searchDepartment";
	}
	
	@RequestMapping(value = "save", method = {RequestMethod.GET, RequestMethod.POST})
	public String saveDepartment(@ModelAttribute("newDepartmentBean")DepartmentBean departmentBean, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		
		List<DepartmentBean> departments = new ArrayList<>();
		departments.add(departmentBean);
		System.out.println("save dept");
		departmentService.saveOrUpdate(departmentBean);
		
	//	model.addAttribute(departments);
		System.out.println("after sabe dept");
		return "redirect:/department/viewDepartment";

	}
	
	@RequestMapping(value = "delete", method = {RequestMethod.GET, RequestMethod.POST})
	public String deleteDepartment(@RequestParam String departmentId, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println(departmentId);
		departmentService.delete(Long.parseLong(departmentId));
		return "redirect:/department/viewDepartment";

	}
	
	@RequestMapping(value = "edit", method = {RequestMethod.GET, RequestMethod.POST})
	public String editDepartment(@RequestParam String departmentId, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		
		System.out.println(departmentId);
		DepartmentBean departmentBean = departmentService.find(Long.parseLong(departmentId));
		model.addAttribute("newDepartmentBean", departmentBean);
		return "AddDepartment";

	}
	
	@RequestMapping(value = "search", method = {RequestMethod.GET, RequestMethod.POST})
	public String searchDepartment(@ModelAttribute("newDepartmentBean")DepartmentBean departmentBean, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println(departmentBean.getDepartmentName());
		List<DepartmentBean> departments = departmentService.findAll(departmentBean.getDepartmentName());
		if(departments.size() > 0)
		{
			model.addAttribute("departments",departments);
			model.addAttribute("message","");
			return "viewDepartment";
		}
		else
		{
			model.addAttribute("message","Record Not Found");
			return "searchDepartment";
		}

	}

}

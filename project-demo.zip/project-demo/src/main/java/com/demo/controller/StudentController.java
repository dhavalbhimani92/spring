package com.demo.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.pojo.DepartmentBean;
import com.demo.pojo.StudentBean;
import com.demo.service.DepartmentService;
import com.demo.service.StudentService;
import com.demo.util.DepartmentEditor;

@Controller
@RequestMapping("/student/")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private DepartmentService departmentService;
	
	public StudentController() {
	}
	
	/*@RequestMapping("/addStudent")
	public String studentForm(@ModelAttribute("newStudentBean")StudentBean studentBean,Model model){
		List<DepartmentBean> department =departmentService.findAll(null);
		Map<Long, DepartmentBean> departmentMap = new LinkedHashMap<>();
		for (DepartmentBean departments : department) {
			   departmentMap.put(departments.getDepartmentId(), departments);
			}
		System.out.println(department.toString());
		model.addAttribute("departmentMap", departmentMap);
		return "studentForm";
	}*/

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		List<DepartmentBean> departments = departmentService.findAll(null);
		Map<Long, DepartmentBean> departmentMap = new LinkedHashMap<>();
		for (DepartmentBean departmentBean : departments) {
			departmentMap.put(departmentBean.getDepartmentId(), departmentBean);
		}
		binder.registerCustomEditor(DepartmentBean.class, new DepartmentEditor(departmentMap));
	}

/*	@ModelAttribute("allDepartments")
	public List<DepartmentBean> populateDepartments() {
		List<DepartmentBean> departments =departmentService.findAll(null);
		return departments;
	}*/
	
	@RequestMapping("/addStudent")
	public String studentForm(@ModelAttribute("newStudentBean")StudentBean studentBean,Model model){
		/*if(studentBean == null){
			studentBean = new StudentBean();
		}*/
		model.addAttribute("student", studentBean);
		model.addAttribute("allDepartments", departmentService.findAll(null));
		return "studentForm";
	}
	
	@RequestMapping("/searchStudent")
	public String searchStudent(@ModelAttribute("newStudentBean")StudentBean studentBean){
		return "searchStudent";
	}
	
	@RequestMapping(value = "save", method = {RequestMethod.GET, RequestMethod.POST})
	public String saveStudent(@ModelAttribute("newStudentBean")@Valid StudentBean studentBean,BindingResult bindingResul , Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Save");
		System.out.println(studentBean.getDepartmentBean());
		System.out.println(studentBean.getDepartmentBean().getDepartmentId());
		/*if(bindingResul.hasErrors()){
			System.out.println("erorororor");
			return "forward:/student/addStudent";
		}*/
		
		List<StudentBean> students = new ArrayList<>();
		students.add(studentBean);
		
		studentService.saveOrUpdate(studentBean);
		
//		model.addAttribute(departments);
		return "redirect:/student/viewStudent";
	}
	
	@RequestMapping("/viewStudent")
	public String viewStudent(Model model, 
			HttpServletRequest request, HttpServletResponse response){
		List<StudentBean> students = studentService.findAll(null);
		model.addAttribute("students",students);
		return "viewStudent";
	}
	
	@RequestMapping(value = "delete", method = {RequestMethod.GET, RequestMethod.POST})
	public String deleteStudent(@RequestParam String studentId, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		studentService.delete(Long.parseLong(studentId));
		return "redirect:/student/viewStudent";
	}
	

	@RequestMapping(value = "edit", method = {RequestMethod.GET, RequestMethod.POST})
	public String editStudent( @RequestParam String studentId, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		
		StudentBean	studentBean = studentService.find(Long.parseLong(studentId));
		model.addAttribute("newStudentBean",studentBean);
		model.addAttribute("allDepartments", departmentService.findAll(null));
		return "studentForm";
	}
	
	@RequestMapping(value = "search", method = {RequestMethod.GET, RequestMethod.POST})
	public String searchStudent(@ModelAttribute("newStudentBean")StudentBean studentBean, Model model, 
			HttpServletRequest request, HttpServletResponse response) {
		List<StudentBean> students = studentService.findAll(studentBean.getStudentName());
		if(students != null && students.size() > 0)
		{
			model.addAttribute("students",students);
			model.addAttribute("message","");
			return "viewStudent";
		}
		else
		{
			model.addAttribute("message","Record Not Found");
			return "searchStudent";
		}
			

	}
}

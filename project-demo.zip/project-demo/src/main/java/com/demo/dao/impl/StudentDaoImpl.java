package com.demo.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.StudentDao;
import com.demo.pojo.DepartmentBean;
import com.demo.pojo.StudentBean;

@Repository("studentDao")
@Transactional
public class StudentDaoImpl implements StudentDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveOrUpdate(StudentBean studentBean) {
		Session session =  sessionFactory.openSession();
		session.getTransaction().begin();
		session.saveOrUpdate(studentBean);
		session.getTransaction().commit();
	}

	@Override
	public List<StudentBean> findAll(String studentName) {
		Session session = sessionFactory.openSession();
		@SuppressWarnings("deprecation")
		Criteria criteria = session.createCriteria(StudentBean.class);
		if(studentName != null){
			criteria.add(Restrictions.eq("studentName", studentName));
		}
		@SuppressWarnings("unchecked")
		List<StudentBean> list = criteria.list();
		return list;
	}

	@Override
	public StudentBean find(Long studentId) {
		Session session = sessionFactory.openSession();
		return session.find(StudentBean.class, studentId);
	}

	@Override
	public void delete(Long studentId) {
		
		Session session =  sessionFactory.openSession();
		session.getTransaction().begin();
		StudentBean studentBean = session.find(StudentBean.class, studentId);
		session.delete(studentBean);
		session.getTransaction().commit();
		
	}

}

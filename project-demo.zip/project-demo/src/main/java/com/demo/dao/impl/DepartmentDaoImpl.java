package com.demo.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.DepartmentDao;
import com.demo.pojo.DepartmentBean;
import com.demo.service.DepartmentService;

@Repository
@Transactional
public class DepartmentDaoImpl implements DepartmentDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveOrUpdate(DepartmentBean departmentBean) {
		System.out.println("dao dept");
		System.out.println(departmentBean.getDepartmentId());
		Session session =  sessionFactory.openSession();
		session.getTransaction().begin();
		session.saveOrUpdate(departmentBean);
		System.out.println("dao dept end");
		session.getTransaction().commit();
	}

	@Override
	public List<DepartmentBean> findAll(String departmentName) {
		Session session = sessionFactory.openSession();
		@SuppressWarnings("deprecation")
		Criteria criteria = session.createCriteria(DepartmentBean.class);
		if(departmentName != null){
			criteria.add(Restrictions.eq("departmentName", departmentName));
		}
		@SuppressWarnings("unchecked")
		List<DepartmentBean> list = criteria.list();
		return list;
	}

	@Override
	public DepartmentBean find(Long departmentId) {
		Session session = sessionFactory.openSession();
		return session.find(DepartmentBean.class, departmentId);
	}

	@Override
	public void delete(Long departmentId) {
		Session session =  sessionFactory.openSession();
		session.getTransaction().begin();
		DepartmentBean departmentBean = session.find(DepartmentBean.class, departmentId);
		session.delete(departmentBean);
		session.getTransaction().commit();
	}

}

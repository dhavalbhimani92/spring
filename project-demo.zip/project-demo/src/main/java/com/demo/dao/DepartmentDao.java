package com.demo.dao;

import java.util.List;

import com.demo.pojo.DepartmentBean;

public interface DepartmentDao {

	void saveOrUpdate(DepartmentBean departmentBean);
	
	List<DepartmentBean> findAll(String departmentName);
	
	DepartmentBean find(Long departmentId);
	
	void delete(Long departmentId);
}
